import './App.css';
import EcommerceStore from './routes/ecommerce-route';
import { UpperNavbar, LowerNavbar, Footer } from './components';
import { AuthProvider } from './context/authcontext'

const App = () => {

  return (
    <div className='app'>
    <AuthProvider>
      <UpperNavbar />
      <LowerNavbar />
      <EcommerceStore />
      {<Footer />}
    </ AuthProvider>
    </div>
  );
};

export default App;
