import RouteData from './route-data';

const EcommerceStore = () => {
  return <RouteData />;
};

export default EcommerceStore;
