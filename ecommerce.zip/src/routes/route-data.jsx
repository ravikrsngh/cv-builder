import { Routes, Route } from 'react-router-dom';
import { Homepage } from '../pages/homepage';
import { Products } from '../pages/products';
import Product from '../pages/product/product';
import Wishlist from '../pages/wishlist/wishlist';
import Cart from '../pages/cart/cart';
import { MyAccount, PersonalDetails, AddressDetails, OrderHistory, TrackOrder, GiftCards, OrderDetails } from '../pages/account/account';
import ComingSoon from '../pages/comingsoon/comingsoon';

// import PrivateRoute from './private-route';

const RouteData = () => {
  return (
    <Routes>
      <Route path='/my-account' element={<MyAccount />} >
        <Route path='personel-details' element={< PersonalDetails />} />
        <Route path='address' element={<AddressDetails/>} />
        <Route path='order-history' element={<OrderHistory/>} />
        <Route path="order-history/:id" element={<OrderDetails/>} />
        <Route path='gift-card' element={<GiftCards/>} />
      </Route>
      <Route path='/blogs' element={<ComingSoon title="Blogs" />} />
      <Route path='/giftings' element={<ComingSoon title="Giftings" />} />
      <Route path='/cart' element={<Cart />} />
      <Route path='/wishlist' element={<Wishlist />} />
      <Route exact path='/products/:product' element={<Product />} />
      <Route path='/products' element={<Products />} />
      <Route path='/' element={<Homepage />} />
    </Routes>
  );
};

export default RouteData;
