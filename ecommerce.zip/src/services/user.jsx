import axios from 'axios';

const base_url = "http://127.0.0.1:8000/"
export const loginuserAPI = async (body) => {
  let result = {}

    await axios.post(base_url + 'api/token/',body).then(function (response) {
          // handle success
          console.log(response);
          result = response.data
        }).catch(function (error) {
          // handle error
          console.log(error);
          result = errr
        });

    return result


}
