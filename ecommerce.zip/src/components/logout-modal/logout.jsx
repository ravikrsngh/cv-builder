import React from 'react';
import ReactDOM from 'react-dom';
import './logout.css';
import loginimg from './../../assets/auth-modal/login.png';
import googleicon from './../../assets/auth-modal/google.png';
import fbicon from './../../assets/auth-modal/fb.png';
import twittericon from './../../assets/auth-modal/twitter.png';
import closeicon from './../../assets/auth-modal/close.png';
import { useState, useEffect, useContext, useRef } from 'react';
import AuthContext from './../../context/authcontext'




const LoginModal = (props) => {

  let { LoginUserWithEmailPassword } = useContext(AuthContext)
  let [email,setEmail] = useState('')
  let [password, setPassword] = useState('')
  let [emailFocus,setEmailFocus] = useState(false)
  let [passwordFocus, setPasswordFocus] = useState(false)

  const onChangeEmailHandler = (e) => {
    if (e.target.value.length == 0) {
      setEmailFocus(false)
    } else {
      setEmailFocus(true)
    }
    setEmail(e.target.value)
  }
  const onChangePasswordHandler = (e) => {
    if (e.target.value.length == 0) {
      setPasswordFocus(false)
    } else {
      setPasswordFocus(true)
    }
    setPassword(e.target.value)
  }

  const closeLogout = () => {
    props.logoutModalHandler(false);
  };

  const openSignup = () => {
    props.logoutModalHandler(false);
    props.loginModalhandler(true)
  }

  const donotcloselogout = (e) => {
    e.stopPropagation();
  };


  return (
    <React.Fragment>
    {ReactDOM.createPortal(
      (
        <div class='auth_popup_main' onClick={closeLogout}>
          <div class='auth_popup_container' onClick={donotcloselogout}>
            <div class='auth_popup_banner'>
              <img src={loginimg} alt='' />
            </div>
            <div class='auth_popup_form'>
              <h3>Have an account? Login in now</h3>
              <form onSubmit={LoginUserWithEmailPassword}>
                <div class='form_container' onMouseEnter={() => setEmailFocus(true)}>
                  <label  className={`${emailFocus && 'label_focused'}`}>Email</label>
                  <input type='email' name='email' onChange={onChangeEmailHandler} value={email} required/>
                </div>
                <div class='form_container' onMouseEnter={() => setPasswordFocus(true)}>
                  <label className={`${passwordFocus && 'label_focused'}`}>Password</label>
                  <input type='password' name='password' onChange={onChangePasswordHandler} value={password} required/>
                </div>
                <div class='form_container'>
                  <button type='submit' name='button'>
                    Login
                  </button>
                </div>
              </form>
              <span className="navspan" onClick={openSignup}>New User? Sign up</span>
              <div class='oauth_container'>
                <div class='oauth_bar'>
                  <div class='line'></div>
                  <span>OR</span>
                  <div class='line'></div>
                </div>
                <div class='oauth_form'>
                  <span>Sign up using</span>
                  <a href='#'>
                    {' '}
                    <img src={googleicon} alt='' />{' '}
                  </a>
                  <a href='#'>
                    {' '}
                    <img src={fbicon} alt='' />{' '}
                  </a>
                  <a href='#'>
                    {' '}
                    <img src={twittericon} alt='' />{' '}
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div className="close_auth_popup"><img src={closeicon} onClick={closeLogout} /> </div>
        </div>
      ),
      document.getElementById('login_logout_modal')
    )}
    </React.Fragment>
  );
};

export default LoginModal;
