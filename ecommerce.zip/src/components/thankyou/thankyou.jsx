import React from 'react';
import ReactDOM from 'react-dom';
import './thankyou.css';
import {useContext, useState} from 'react';
import AuthContext from './../../context/authcontext';
import checkicon from './../../assets/Checkicon.png'



const ThankYouModal = (props) => {
  let {user} = useContext(AuthContext)

  return (
    <React.Fragment>
      {ReactDOM.createPortal(
        (
          <div className='review-modal-main thank-you-modal'>
            <div className="review-modal-container">
              <div className="checkmark">
                <img src={checkicon} />
              </div>

              <h2>Thank You For Your Order !</h2>

              <p>Your order <span>{props.order_id}</span> has successfully been placed. You’ll find all the details about your order on your account section, and we’ll send you a shipping confrimation email as soon as your order ships. </p>

              <p>Questions? Suggestions? insightful showe thoughts?</p>
              <p><a>Shoot us an email.</a></p>

              <button><a href="/products">Browse More Products</a></button>
            </div>
          </div>
        ),
        document.getElementById('login_alert_modal')
      )}
    </React.Fragment>


  );
};

export default ThankYouModal;
