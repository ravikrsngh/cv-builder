import React from 'react';
import ReactDOM from 'react-dom';
import './login.css';
import signup from './../../assets/auth-modal/signup.png';
import googleicon from './../../assets/auth-modal/google.png';
import fbicon from './../../assets/auth-modal/fb.png';
import twittericon from './../../assets/auth-modal/twitter.png';
import closeicon from './../../assets/auth-modal/close.png';
import { useState, useEffect, useContext, useRef } from 'react';
import AuthContext from './../../context/authcontext'

const LoginModal = (props) => {
  const {SignUpUserWithEmailPassword} = useContext(AuthContext)
  const closeLogin = () => {
    props.loginModalhandler(false);
  };
  const donotcloselogin = (e) => {
    e.stopPropagation();
  };
  const openLogin= () => {
    props.logoutModalHandler(true);
    props.loginModalhandler(false)
  }

  let [email,setEmail] = useState('')
  let [password, setPassword] = useState('')
  let [name, setName] = useState('')
  let [emailFocus,setEmailFocus] = useState(false)
  let [passwordFocus, setPasswordFocus] = useState(false)
  let [nameFocus, setNameFocus] = useState(false)

  const onChangeEmailHandler = (e) => {
    if (e.target.value.length == 0) {
      setEmailFocus(false)
    } else {
      setEmailFocus(true)
    }
    setEmail(e.target.value)
  }

  const onChangePasswordHandler = (e) => {
    if (e.target.value.length == 0) {
      setPasswordFocus(false)
    } else {
      setPasswordFocus(true)
    }
    setPassword(e.target.value)
  }

  const onChangeNameHandler = (e) => {
    if (e.target.value.length == 0) {
      setNameFocus(false)
    } else {
      setNameFocus(true)
    }
    setName(e.target.value)
  }


  return (
    <React.Fragment>
    {ReactDOM.createPortal(
      (
        <div class='auth_popup_main' onClick={closeLogin}>
          <div class='auth_popup_container' onClick={donotcloselogin}>
            <div class='auth_popup_banner'>
              <img src={signup} alt='' />
            </div>
            <div class='auth_popup_form'>
              <h3>Create an account</h3>
              <form onSubmit={SignUpUserWithEmailPassword}>
                <div class='form_container' onMouseEnter={() => setNameFocus(true)}>
                  <label  className={`${nameFocus && 'label_focused'}`}>Name</label>
                  <input type='text' name='name' onChange={onChangeNameHandler} value={name} required/>
                </div>
                <div class='form_container' onMouseEnter={() => setEmailFocus(true)}>
                  <label  className={`${emailFocus && 'label_focused'}`}>Email</label>
                  <input type='email' name='email' onChange={onChangeEmailHandler} value={email} required/>
                </div>
                <div class='form_container' onMouseEnter={() => setPasswordFocus(true)}>
                  <label className={`${passwordFocus && 'label_focused'}`}>Password</label>
                  <input type='password' name='password' onChange={onChangePasswordHandler} value={password} required/>
                </div>
                <div class='form_container'>
                  <button type='submit' name='button'>
                    Create Account
                  </button>
                </div>
              </form>
              <span className="navspan" onClick={openLogin}>Existing user? Login</span>
              <div class='oauth_container'>
                <div class='oauth_bar'>
                  <div class='line'></div>
                  <span>OR</span>
                  <div class='line'></div>
                </div>
                <div class='oauth_form'>
                  <span>Sign up using</span>
                  <a href='#'>
                    {' '}
                    <img src={googleicon} alt='' />{' '}
                  </a>
                  <a href='#'>
                    {' '}
                    <img src={fbicon} alt='' />{' '}
                  </a>
                  <a href='#'>
                    {' '}
                    <img src={twittericon} alt='' />{' '}
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div className="close_auth_popup"><img src={closeicon} onClick={closeLogin} /> </div>
        </div>
      ),
      document.getElementById('login_logout_modal')
    )}
    </React.Fragment>
  );
};

export default LoginModal;
