import React from 'react';
import { Link } from 'react-router-dom';
import './footer.css';
import fbicon from './../../assets/footer/fb.png';
import twittericon from './../../assets/footer/twitter.png';
import linkednicon from './../../assets/footer/linkedn.png';
import instaicon from './../../assets/footer/insta.png';
import paymenticon from './../../assets/footer/payment.png';

const Footer = () => {
  return (
    <footer className='footer'>
      <div className='footer-top'>
        <div className='footer-column'>
          <h3>ABOUT THE SHOP</h3>
          <p>
            Lorem Ipsum is simply dummy text of the printing and typesetting
            industry. Lorem Ipsum has been the industry's standard dummy text
            ever since the 1500s
          </p>
          <div className="footer_social">
            <Link><img src={fbicon} /></Link>
            <Link><img src={twittericon} /></Link>
            <Link><img src={linkednicon} /></Link>
            <Link><img src={instaicon} /></Link>
          </div>
        </div>
        <div className='footer-column'>
          <h3>MENU</h3>
          <Link className='footer-link'><a>Home</a></Link>
          <Link className='footer-link'><a>Jewllery</a></Link>
          <Link className='footer-link'><a>Ring</a></Link>
          <Link className='footer-link'><a>Earring</a></Link>
          <Link className='footer-link'><a>Other</a></Link>
          <Link className='footer-link'><a>Gifting</a></Link>
        </div>
        <div className='footer-column'>
          <h3>SUPPORT</h3>
          <Link className='footer-link'><a>Frequently Asked Questions</a></Link>
          <Link className='footer-link'><a>Returns and Refunds</a></Link>
          <Link className='footer-link'><a>CGV</a></Link>
          <Link className='footer-link'><a>Legal Notice</a></Link>
          <Link className='footer-link'><a>Track My Order</a></Link>
        </div>
        <div className='footer-column'>
          <h3>Reachable 24/7</h3>
          <p>A question ? We can be reached by email 7/7, do not hesitate to send us a message for any request</p>
          <a className="footer-email">info@tawisa .com</a>
        </div>
      </div>
      <div className='footer-bottom'>
        <h3>© Tawisa- fine jewelry 2022</h3>
        <img src={paymenticon} />
      </div>
    </footer>
  );
};

export default Footer;
