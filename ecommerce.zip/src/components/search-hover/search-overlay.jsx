import React from 'react';
import './search-overlay.css';
import { useEffect, useState } from 'react';
import {Link} from 'react-router-dom';


const SearchOverlay = () => {

  let [recentSearches, setrecentSearches] = useState(localStorage.getItem('recent_searches')? JSON.parse(localStorage.getItem('recent_searches')) : ['Rings','Earrings','Necklaces','Sets','Others'])
  let [popular_products, setpopular_products] = useState([])
  useEffect(() => {
    if (sessionStorage.getItem("popular_products")) {

    }
  })


  return (
    <div className='search-overlay'>
      <div className='search-overlay-recent'>
        <p className='search-overlay-recent-title'>Your Recent Searches</p>
        {recentSearches.map((ins) => {
            return <p className='search-overlay-recent-p'><Link to={`/products?search=${ins}`}>{ins}</Link></p>
        })}
      </div>
      <div className='search-overlay-popular'>
        <p>Popular Products</p>
        <div className='search-overlay-popular-items-container'>
          <div className='search-overlay-popular-items'>
            <div className='search-overlay-picture'>x</div>
            <div className='search-overlay-popular-detail'>
              <p>Sofia brichet</p>
              <p>₹ 7642</p>
            </div>
          </div>
          <div className='search-overlay-popular-items'>
            <div className='search-overlay-picture'>x</div>
            <div className='search-overlay-popular-detail'>
              <p>Sofia brichet</p>
              <p>₹ 7642</p>
            </div>
          </div>
          <div className='search-overlay-popular-items'>
            <div className='search-overlay-picture'>x</div>
            <div className='search-overlay-popular-detail'>
              <p>Sofia brichet</p>
              <p>₹ 7642</p>
            </div>
          </div>
          <div className='search-overlay-popular-items'>
            <div className='search-overlay-picture'>x</div>
            <div className='search-overlay-popular-detail'>
              <p>Sofia brichet</p>
              <p>₹ 7642</p>
            </div>
          </div>
          <div className='search-overlay-popular-items'>
            <div className='search-overlay-picture'>x</div>
            <div className='search-overlay-popular-detail'>
              <p>Sofia brichet</p>
              <p>₹ 7642</p>
            </div>
          </div>
          <div className='search-overlay-popular-items'>
            <div className='search-overlay-picture'>x</div>
            <div className='search-overlay-popular-detail'>
              <p>Sofia brichet</p>
              <p>₹ 7642</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SearchOverlay;
