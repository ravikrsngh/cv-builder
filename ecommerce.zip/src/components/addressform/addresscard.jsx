import outline_heart from './../../assets/products-card/outline_heart.png'
import black_filled_heart from './../../assets/products-card/black_filled_heart.png'
import {useState} from 'react'


const AddressCard = (props) => {

  return (
    <div className='address-card'>
      <p>
      {props.address.first_name} {props.address.last_name} <br />
      {props.address.phone_number} <br />
      {props.address.address_line1}, {props.address.city}, {props.address.state} - {props.address.zipcode}
      </p>
      <img src={props.icon} onClick={()=> {
        props.iconAction(props.address)
      }}/>
    </div>
  )
}

export default AddressCard
