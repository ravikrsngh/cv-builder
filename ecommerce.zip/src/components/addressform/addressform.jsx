import React from 'react';
import { Link } from 'react-router-dom';
import './addressform.css';
import fbicon from './../../assets/footer/fb.png';
import twittericon from './../../assets/footer/twitter.png';
import linkednicon from './../../assets/footer/linkedn.png';
import instaicon from './../../assets/footer/insta.png';
import paymenticon from './../../assets/footer/payment.png';
import AddressCard from './addresscard'
import axios from 'axios'
import {useContext, useRef} from 'react';
import AuthContext from './../../context/authcontext';

const AddressForm = (props) => {
  let {authTokens, base_url} = useContext(AuthContext)
  let addressFormRef = useRef()
  const addAddress = async (e) => {
    e.preventDefault()
    let body = {
      "first_name":e.target.first_name.value,
      "last_name":e.target.last_name.value,
      "country":e.target.country.value,
      "state":e.target.state.value,
      "address_line1":e.target.address_line1.value,
      "address_line2":"-",
      "city":e.target.city.value,
      "zipcode":e.target.zipcode.value,
      "phone_number":e.target.phone_number.value,
    }
    await axios.post(base_url + "/api/address/",body,{
      'headers':{
        'Authorization': 'Bearer ' + String(authTokens.access)
      }
    }).then(function (response) {
      console.log(response.data);
      props.setaddressList((prev) => {
        return [...prev,response.data]
      })
      props.setaddressFormDisplay(false)
      addressFormRef.current.reset()
      }).catch(function (error) {
        console.log(error);
      });
  }

  return (
    <form ref={addressFormRef} onSubmit={addAddress} className="addressForm" style={{"height":`${props.display? 'auto':'0px'}`}}>
      <div className="addressForm-input-container">
        <label className="addressForm-input-label">First Name</label>
        <input className="addressForm-input-box addressForm-input-stretched" type="text" name="first_name" placeholder="First Name" required/>
      </div>
      <div className="addressForm-input-container">
        <label className="addressForm-input-label">Last Name</label>
        <input className="addressForm-input-box " type="text" placeholder="Last Name" name="last_name" required/>
      </div>
      <div className="addressForm-input-container addressForm-input-container-long">
        <label className="addressForm-input-label">Country</label>
        <input className="addressForm-input-box " type="text" placeholder="Country" name="country" required/>
      </div>
      <div className="addressForm-input-container addressForm-input-container-long">
        <label className="addressForm-input-label">Street Address</label>
        <input className="addressForm-input-box " type="text" placeholder="Street Address" name="address_line1" required />
      </div>
      <div className="addressForm-input-container addressForm-input-container-long">
        <label className="addressForm-input-label">City</label>
        <input className="addressForm-input-box " type="text" placeholder="City" name="city" required/>
      </div>
      <div className="addressForm-input-container">
        <label className="addressForm-input-label">State</label>
        <input className="addressForm-input-box addressForm-input-stretched" type="text" name="state" placeholder="State" required/>
      </div>
      <div className="addressForm-input-container">
        <label className="addressForm-input-label">Zip Code</label>
        <input className="addressForm-input-box " type="text" placeholder="Zip Code" name="zipcode" required/>
      </div>
      <div className="addressForm-input-container addressForm-input-container-long">
        <label className="addressForm-input-label">Phone Number</label>
        <input className="addressForm-input-box " type="text" placeholder="Phone Number" name="phone_number" required/>
      </div>
      <div className="addressForm-input-container addressForm-input-container-long">
        <button type="submit">Save Address</button>
      </div>
    </form>
  );
};

export default AddressForm;
