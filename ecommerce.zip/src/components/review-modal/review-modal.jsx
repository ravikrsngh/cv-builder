import React from 'react';
import ReactDOM from 'react-dom';
import './review-modal.css';
import {useContext, useState} from 'react';
import AuthContext from './../../context/authcontext';
import LoginModal from '../login-modal/login';
import LogoutModal from '../logout-modal/logout';



const ReviewModal = (props) => {
  let {user} = useContext(AuthContext)
  const [loginModal, setLoginModal] = useState(false);
  const [logoutModal, setLogoutModal] = useState(false);

  const SubmitReview = (e) => {
    console.log("Submitting Review");
    e.preventDefault();
    props.submitReview(e.target.name.value,e.target.message.value)
  }

  return (
    <React.Fragment>
      {ReactDOM.createPortal(
        (
          <div className='review-modal-main'>

            {user?
              (
                <form className='review-modal-container' onSubmit={SubmitReview}  onClick={(e) => e.stopPropagation() }>
                <h1 className='review-modal-heading'>Leave a Review</h1>
                <input
                  className='review-modal-input'
                  type='text'
                  placeholder='Name'
                  name="name"
                  required
                />
                <input
                  className='review-modal-input'
                  type='text'
                  placeholder='Message'
                  name="message"
                  required
                />
                <button type="submit">Upload</button>
              </form>
            ) : (
              <div className='review-modal-nologin review-modal-container'>
                <h2>OOPS ! You are not logged in</h2>
                <h3>Login or Signup to continue.</h3>
                <div onClick={(e) => e.stopPropagation()}>
                  <button onClick={() => setLogoutModal(true)}>Login</button>
                  <button onClick={() => setLoginModal(true)} className="signup">Sign up</button>
                </div>
                <p><span style={{color:"rgba(239, 36, 36, 1)"}}>Having Issues?</span> <span style={{color:"rgba(47, 171, 247, 1)"}}>Contact Us.</span></p>
              </div>
            )
            }

            {loginModal && <LoginModal loginModalhandler={setLoginModal} logoutModalHandler={setLogoutModal} />}
            {logoutModal && <LogoutModal logoutModalHandler={setLogoutModal} loginModalhandler={setLoginModal} />}

          </div>
        ),
        document.getElementById('login_alert_modal')
      )}
    </React.Fragment>


  );
};

export default ReviewModal;
