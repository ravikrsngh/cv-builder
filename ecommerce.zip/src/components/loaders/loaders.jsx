import React from 'react';
import ReactDOM from 'react-dom'
import './loaders.css'

export const HomePageLoader = () => {
  return (
    <React.Fragment>
    {ReactDOM.createPortal(
      (
        <div className="loader_outer_container" id="homepageloader">

          <div className="big animate"></div>
          <div className="small animate"></div>
          <div className="small animate"></div>
          <div className="small animate"></div>
          <div className="small animate"></div>

          <div className="big animate"></div>
          <div className="small animate"></div>
          <div className="small animate"></div>
          <div className="small animate"></div>
          <div className="small animate"></div>

        </div>
      ),
      document.getElementById('loader')
    )}
    </React.Fragment>
  )
}



export const ProductsPageLoader = () => {
  return (
        <div className="loader_outer_container products_page_loader" id="products_page_loader">

          <div className="animate_card">
            <div className="animate_card_img animate"></div>
            <div className="animate_card_info animate"></div>
            <div className="animate_card_info animate"></div>
            <div className="animate_card_info animate"></div>
          </div>
          <div className="animate_card">
            <div className="animate_card_img animate"></div>
            <div className="animate_card_info animate"></div>
            <div className="animate_card_info animate"></div>
            <div className="animate_card_info animate"></div>
          </div>
          <div className="animate_card">
            <div className="animate_card_img animate"></div>
            <div className="animate_card_info animate"></div>
            <div className="animate_card_info animate"></div>
            <div className="animate_card_info animate"></div>
          </div>
          <div className="animate_card">
            <div className="animate_card_img animate"></div>
            <div className="animate_card_info animate"></div>
            <div className="animate_card_info animate"></div>
            <div className="animate_card_info animate"></div>
          </div>
          <div className="animate_card">
            <div className="animate_card_img animate"></div>
            <div className="animate_card_info animate"></div>
            <div className="animate_card_info animate"></div>
            <div className="animate_card_info animate"></div>
          </div>
          <div className="animate_card">
            <div className="animate_card_img animate"></div>
            <div className="animate_card_info animate"></div>
            <div className="animate_card_info animate"></div>
            <div className="animate_card_info animate"></div>
          </div>
        </div>
  )
}



export const ProductDetailsPageLoader = () => {
  return (
    <React.Fragment>
    {ReactDOM.createPortal(
      (
        <div className="loader_outer_container" id="productdetailsloader">

          <div className="big animate"></div>
          <div className="left">
          <div className="small animate"></div>
          <div className="small animate"></div>
          <div className="small animate"></div>
          <div className="small animate"></div>
          </div>

          <div className="big animate"></div>

        </div>
      ),
      document.getElementById('loader')
    )}
    </React.Fragment>
  )
}

export const AccountDetailsPageLoader = () => {
  return (
        <div className="loader_outer_container" id="accountdetailsloader">

        <div className="left">
          <div className="small animate"></div>
          <div className="small animate"></div>
          <div className="small animate"></div>
          <div className="small animate"></div>
          <div className="small animate"></div>
          <div className="small animate"></div>
          <div className="small animate"></div>
          <div className="small animate"></div>
        </div>

        </div>
  )
}


export const PaymentLoader = () => {
  return (
    <React.Fragment>
    {ReactDOM.createPortal(
      (
            <div className="payment_loader" id="payment_loader">

              <div>
              </div>

            </div>
      ),
      document.getElementById('loader')
    )}
    </React.Fragment>
  )
}
