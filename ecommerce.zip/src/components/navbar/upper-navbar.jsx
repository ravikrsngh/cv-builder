import React, { useState, useEffect, useRef } from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import './upper-navbar.css';
import LoginModal from '../login-modal/login';
import LogoutModal from '../logout-modal/logout';
import carticon from './../../assets/shopping_bag.svg';
import wishlisticon from './../../assets/wishlist.svg';
import menuicon from './../../assets/menuicon.png';
import profileimg from './../../assets/profileimg.png';
import closeicon from './../../assets/closenoborder.png';
import {useContext} from 'react'
import AuthContext from './../../context/authcontext'
import jwt_decode from "jwt-decode";

const UpperNavbar = () => {
  let navigate = useNavigate()
  const wrapperRef = useRef(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isDialog, setIsDialog] = useState(false);
  const [loginModal, setLoginModal] = useState(false);
  const [logoutModal, setLogoutModal] = useState(false);
  const [displayProfileNav, setdisplayProfileNav] = useState(false)
  const [mobileHeaderDisplay, setmobileHeaderDisplay] = useState(false)
  const [userDetails,setUserDetails] = useState({})

  const auth_ctx = useContext(AuthContext)



  return (
    <nav>

      <div ref={wrapperRef} className='upper-nav-container'>
      <NavLink to='/wishlist' className='upper-nav-cart'>
        <img src={wishlisticon} className='upper-nav-cart-icon' />
      </NavLink>
      <NavLink to='/cart' className='upper-nav-cart'>
        <img src={carticon} className='upper-nav-cart-icon' />
      </NavLink>

      {!auth_ctx.user ? (
        <button
          className='upper-nav-button'
          onMouseEnter={() => setIsDialog(true)}
        >
          Login/Sign up
        </button>
      ) : (
        <div className='upper-nav-profile' onMouseEnter={() => setdisplayProfileNav(true)}>
          <p>{jwt_decode(auth_ctx.authTokens.access).name}</p>
          <div className='upper-nav-profile-picture'><img src={jwt_decode(auth_ctx.authTokens.access).profile_pic? jwt_decode(auth_ctx.authTokens.access).profile_pic : profileimg } /></div>
        </div>
      )}
      <div
        onMouseLeave={() => setIsDialog(false)}
        className={isDialog ? 'nav-hover-dialog' : 'nav-hover-dialog-hidden'}
      >
        <p>Login / Sign up to access your account</p>
        <div className='nav-dialog-buttons'>
          <button
            onClick={() => setLogoutModal(true)}
            className='nav-dialog-login'
          >
            LOGIN
          </button>
          <button
            onClick={() => setLoginModal(true)}
            className='nav-dialog-signup'
          >
            SIGN UP
          </button>
        </div>
        <div className='nav-dialog-footer'>
          <p className='nav-dialog-issues'>Having issues?</p>
          <p className='nav-dialog-contact'>Contact Us</p>
        </div>
      </div>

      { auth_ctx.user && <div onMouseLeave={() => setdisplayProfileNav(false)} className={`on-profile-dialog ${displayProfileNav? '' : 'on-profile-dialog-hide'}`}>
        <h3>Hello, <br/> {jwt_decode(auth_ctx.authTokens.access).name}</h3>
        <NavLink to="/my-account"><span>My Account</span></NavLink>
        <NavLink to="/my-account"><span>Order History</span></NavLink>
        <NavLink to="/my-account"><span>Track Order</span></NavLink>
        <NavLink to="/my-account"><span>Contact</span></NavLink>
        <span class="last" onClick={ auth_ctx.LogoutUser }>Logout</span>
      </div> }


      </div>

      <div className="mobile-upper-nav">
        <Link to='/'> <span>TAWISA</span> </Link>
        <button onClick={() => {setmobileHeaderDisplay(true)}}><img src={menuicon} /></button>
      </div>

      { mobileHeaderDisplay &&
        <div className="mobile-menu-container">

        <div className="mobile-menu-header">
          <Link onClick={() => location.href="/wishlist"} ><img src={wishlisticon} /></Link>

          <div>
            { !auth_ctx.user? (<button onClick={() => {
              setLogoutModal(true)
              setmobileHeaderDisplay(false)}}>LOGIN / SIGN UP</button>) :(
              <div className="mobile-menu-header-profile" style={{"cursor":"pointer"}} onClick={() => {
                setmobileHeaderDisplay(false)
                navigate('/my-account')
              }}>
                <div className='upper-nav-profile-picture'><img src={jwt_decode(auth_ctx.authTokens.access).profile_pic? jwt_decode(auth_ctx.authTokens.access).profile_pic : profileimg  } /></div>
                <h4>{jwt_decode(auth_ctx.authTokens.access).name}</h4>
              </div>
            ) }
          </div>

          <NavLink onClick={() => location.href="/cart"}><img src={carticon} /></NavLink>
        </div>

        <div className="mobile-menu-links-container">
          <div className="mobile-menu-links">
            <Link onClick={() => location.href="/products"} >All Products</Link>
            <Link onClick={() => location.href="/products?category=Rings"} >Rings</Link>
            <Link onClick={() => location.href="/products"} >Jewellery</Link>
            <Link onClick={() => location.href="/products?category=Earrings"} >Earrings</Link>
            <Link onClick={() => location.href="/"} >Blogs</Link>
            <Link onClick={() => location.href="/"} >Gifting</Link>
            {auth_ctx.user && <div className="mobile-logout-link">
              <Link onClick={() => {
                auth_ctx.LogoutUser()
                setmobileHeaderDisplay(false)
              }}>Logout</Link>
            </div>}
            <Link onClick={() => location.href="/"}  style={{"marginTop":"50px"}}><span style={{"color":"rgba(239, 36, 36, 1)"}}>Having issues?</span> <span style={{"color":"rgba(47, 171, 247, 1)"}}>Contact Us</span></Link>
          </div>
        </div>

        <div className="close-mobile-menu">
          <button onClick={() => {setmobileHeaderDisplay(false)}}><img src={closeicon} /></button>
        </div>

        </div>
      }

      {loginModal && <LoginModal loginModalhandler={setLoginModal} logoutModalHandler={setLogoutModal} />}
      {logoutModal && <LogoutModal logoutModalHandler={setLogoutModal} loginModalhandler={setLoginModal} />}

    </nav>
  );
};

export default UpperNavbar;
