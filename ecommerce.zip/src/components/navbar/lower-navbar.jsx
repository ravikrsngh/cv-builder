import React, { useState, useRef } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import './low-navbar.css';
import searchicon from './../../assets/search.svg';
import SearchOverlay from '../search-hover/search-overlay';


const LowerNavbar = () => {
  const [isSearchDialog, setIsSearchDialog] = useState(true);
  const searchRef = useRef()

  const navigate = useNavigate()

  const SearchProduct = () => {
    let val = searchRef.current.value
    navigate('/products?search=' + val)
  }

  return (
    <nav
      className='lower-nav-container'
      onMouseLeave={() => setIsSearchDialog(false)} >
      <NavLink to='/' className="logolink">
        <h2>TAWISA</h2>
      </NavLink>
      <div className='lower-nav-link-container'>
        <NavLink to='/products' className='lower-nav-link'>
          All products
        </NavLink>
        <NavLink to='/products/?category=Rings' className='lower-nav-link'>
          Rings
        </NavLink>
        <NavLink to='/products/?category=Earrings' className='lower-nav-link'>
          Earrings
        </NavLink>
        <NavLink to='/products' className='lower-nav-link'>Jewellery</NavLink>
        <NavLink to='/blogs' className='lower-nav-link'>Blogs</NavLink>
        <NavLink to='/giftings' className='lower-nav-link'>Gifting</NavLink>
      </div>
      <div className='lower-nav-input'>
        <input type='text' ref={searchRef} placeholder='Search For Anything' onMouseEnter={() => setIsSearchDialog(true)} />
        <img src={searchicon} className='lower-nav-search' onClick={SearchProduct} />
      </div>

      {isSearchDialog && <SearchOverlay />}
    </nav>
  );
};

export default LowerNavbar;
