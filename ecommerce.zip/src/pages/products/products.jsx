import React, { useEffect, useState, useContext } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import ProductsHero from './product-components/product-hero/products-hero';
import { ThirdSection, ItemCard, MultiRangeSlider } from '../../components/';
import filtericon from './../..//assets/filtericon.png';
import AuthContext from './../../context/authcontext';
import { HomePageLoader, ProductsPageLoader } from '../../components/loaders/loaders';
import './products.css';
import axios from 'axios';


const ProductFilterCategory = (props) => {
  const location = useLocation()
  const navigate = useNavigate()

  const applyThisFilter = (name) => {
    let new_search_string = "tags=" + name
    let search_string = location.search
    if (search_string == "") {
      search_string = "?tags=" + name
      navigate('/products' + search_string)
    }
    if (search_string == "?") {
      search_string = "tags=" + name
      navigate('/products' + search_string)
    }
    if (search_string.includes(new_search_string)) {
      return
    } else {
      navigate('/products' + search_string+"&"+new_search_string)
    }

  }

  return (
    <div className='filter-category-container'>
      <h3>{props.title}</h3>
      {props.options.map((ins) => {
        return (
          <div className='filter-category' onClick={() => applyThisFilter(`${ins.name}`)}>
            { ins.icon == "None" ? <img style={{display:"none"}} /> : <img src={ins.icon} />}
            {ins.name}
            <span className='filter-cat-num'>12</span>
          </div>
        )
      })}
    </div>
  )
}

const FilterTags = (props) => {

  const location = useLocation()
  const navigate = useNavigate()

  const removeThisFilter = (type, label) => {
    let remove_search_string1 = "&"+ type +"=" + label
    let remove_search_string2 = type +"=" + label
    let search_string = location.search.replace(remove_search_string1,'').replace(remove_search_string2,'')
    navigate('/products' + search_string)
  }

  return (
    <div className='selected-filters'>
      <p>{props.label}</p>
      <svg width='19' height='19' viewBox='0 0 19 19' fill='none' xmlns='http://www.w3.org/2000/svg' onClick={() => removeThisFilter(`${props.type}`, `${props.label}`)}>
        <path
          fill-rule='evenodd'
          clip-rule='evenodd'
          d='M8.7593 0.0282519C6.06464 0.234659 3.53995 1.62388 1.91095 3.79657C0.168454 6.12066 -0.417679 9.05272 0.298479 11.8625C1.14667 15.1902 3.81145 17.8547 7.13761 18.7008C10.4154 19.5347 13.8152 18.6006 16.2094 16.2083C18.5975 13.8222 19.5347 10.4113 18.7017 7.1378C17.928 4.09676 15.5978 1.56365 12.6217 0.528162C11.3814 0.0966207 10.0747 -0.0724807 8.7593 0.0282519ZM6.80607 5.78792C6.93111 5.82173 7.15683 6.02959 8.22746 7.09677L9.50021 8.36543L10.773 7.09651C11.9127 5.96025 12.0631 5.823 12.2126 5.78365C12.8337 5.61989 13.3808 6.16703 13.2171 6.78807C13.1777 6.93748 13.0405 7.08793 11.9041 8.22754L10.635 9.50016L11.9041 10.7728C13.0405 11.9124 13.1777 12.0628 13.2171 12.2123C13.3802 12.831 12.8313 13.3798 12.2126 13.2167C12.0631 13.1773 11.9127 13.0401 10.773 11.9038L9.50021 10.6349L8.22746 11.9038C7.08774 13.0401 6.93728 13.1773 6.78786 13.2167C6.16906 13.3798 5.62016 12.831 5.78333 12.2123C5.82269 12.0628 5.95996 11.9124 7.09633 10.7728L8.36536 9.50016L7.09633 8.22754C5.95996 7.08793 5.82269 6.93748 5.78333 6.78807C5.68267 6.4064 5.84524 6.03041 6.18846 5.85112C6.40135 5.73991 6.56616 5.72304 6.80607 5.78792Z'
          fill='#9D838C' />
      </svg>
    </div>
  )
}


const Products = () => {

  let [productList, setproductList] = useState([])
  let [selectedFilter, setselectedFilter] = useState([])
  let [productFilters, setproductFilters] = useState([])
  let [mobileFilterDisplay, setmobileFilterDisplay] =  useState(false)
  let [searchPriceRange, setsearchPriceRange] = useState({selling_price_min:2000,selling_price_max:150000})
  let [isLoading, setisLoading] =  useState(true)
  let [isProductLoading, setisProductLoading] =  useState(true)


  let {user, authTokens, base_url} = useContext(AuthContext)
  const location = useLocation()
  const navigate = useNavigate()

  const filterCollection = async (search_string) => {

    setisProductLoading(true)
    /* Filters Selected */
    let filterstrings = search_string.slice(1).split("&")
    let l = filterstrings.map((ins) => {
      if (ins == "") {
        return false
      }
      return ins.split("=")
    })
    l = l.map((ins) => {
      if (!ins) {
        return
      }
      return (
        <FilterTags type={ins[0]} label={ins[1]} />
      )
    })
    setselectedFilter(l)

    /* Check Wishlist */
    let wishlist_id = []
    if (user) {
      if (localStorage.getItem("wishlistChanged") == "true") {
        await axios.get(base_url + "/api/wishlist/",{
          'headers':{
            'Authorization': 'Bearer ' + String(authTokens.access)
          }
        }).then(function (response) {
            response.data.map((ins) => wishlist_id.push(ins.product.id))
            localStorage.setItem("wishlist",JSON.stringify(wishlist_id))
            localStorage.setItem("wishlistChanged","false")
          }).catch(function (error) {
              console.log(error);
          });
      }
      else {
        if (localStorage.getItem("wishlist")) {
          wishlist_id = JSON.parse(localStorage.getItem("wishlist"))
        }
      }
    }



    await axios.get(base_url + "/api/products" + search_string).then(function (response) {
        response = response.data
        let list = response.map((ins, i) => {
          return (
            <ItemCard key={ins.id} id={ins.id} title={ins.title} stars={ins.avg_rating} price={ins.selling_price} images={ins.product_images} is_wishlisted={wishlist_id.includes(ins.id)? true : false} />
          )
        })
        setproductList(list)
        if (isLoading) {
          setisLoading(false)
        }
        setisProductLoading(false)

      }).catch(function (error) {
          console.log(error);
      });
  }

  const loadProductFilterCategories = async () => {
    await axios.get(base_url +"/api/filteroptions?display=true").then(function (response) {
        response = response.data
        let list = response.map((ins, i) => {
          return (
            <ProductFilterCategory key={i} id={ins.id} title={ins.title} options={ins.filter_option_items} />
          )
        })
        setproductFilters(list)
      }).catch(function (error) {
          console.log(error);
      });
  }

  const applyPriceFilter = () => {
    let selling_price_min =  document.getElementById('slider_left_value').innerHTML
    let selling_price_max = document.getElementById('slider_right_value').innerHTML
    let search_string = location.search
    if (search_string == "") {
      search_string = "?selling_price_min=" + selling_price_min + "&selling_price_max="+ selling_price_max
      navigate('/products' + search_string)
    } else if (search_string == "?") {
      search_string = "?selling_price_min=" + selling_price_min + "&selling_price_max="+ selling_price_max
      navigate('/products' + search_string)
    } else {
        navigate("/products"+ search_string+"&selling_price_min=" + selling_price_min + "&selling_price_max="+ selling_price_max)
    }

  }

  const clearAllFilters = () => {
    navigate('/products')
  }



  useEffect(() => {
    filterCollection(location.search)
    if (window.innerWidth > 1000) {
      setmobileFilterDisplay(true)
    }
  }, [location]);

  useEffect(() => {
    const handleWindowResize = () => {
      if (window.innerWidth > 1000) {
        setmobileFilterDisplay(true)
      } else {
        setmobileFilterDisplay(false)
      }
    }
    window.addEventListener("resize", handleWindowResize);
    return () => window.removeEventListener("resize", handleWindowResize);
  }, []);

  useEffect(() => {
    loadProductFilterCategories()
  }, []);

  if (isLoading) {
    return <HomePageLoader />
  }

  return (
    <main >
      <ProductsHero />
      <ThirdSection />
      <div className='products-divide'>
        <p>Showing 1-12 results</p>
        <p>Sort by latest products</p>
        <button className="filter-option-btn" onClick={() => {
          setmobileFilterDisplay(true)
        }}><img src={filtericon} />Filter </button>
      </div>
      <section className='products-container'>
        <div className='products-filter-container' style={{"display":`${mobileFilterDisplay? 'block':'none'}`}}>
          <div className="mobile-filter-header">
            <h4 style={{"cursor":"pointer"}} onClick={() => {
              setmobileFilterDisplay(false)
            }}>Close</h4>
            <button className="filter-option-btn" onClick={clearAllFilters}>CLEAR ALL </button>
          </div>
          <div className='selected-filters-container'>
            {selectedFilter}
          </div>
          <div className='filter-range-container'>
            <h3>Price</h3>
            <MultiRangeSlider
              min={2000}
              max={150000}
              onChange={({ min, max }) => {return} }
            />
            <button className="apply-price-filter-btn" onClick={applyPriceFilter}>Apply Price Filter</button>
          </div>
          {productFilters}
        </div>
        <div style={{"position":"relative"}}>
          { isProductLoading? (
            <ProductsPageLoader />
          ) : (
            <div className='products-items-container' id="products-items-container">
              {productList}
            </div>
          )}
        </div>
      </section>

    </main>
  );
};

export default Products;
