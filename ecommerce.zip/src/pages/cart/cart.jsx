import React, { useState, useEffect } from 'react';
import { WishlistItemCard, RecSection, ItemCard, AddressForm } from '../../components/';
import './cart.css';
import {useContext} from 'react';
import AuthContext from './../../context/authcontext';
import LoginModal from '../../components/login-modal/login';
import LogoutModal from '../../components/logout-modal/logout';
import ThankYouModal from '../../components/thankyou/thankyou';
import { HomePageLoader, PaymentLoader } from '../../components/loaders/loaders';
import axios from 'axios'
import {Link} from 'react-router-dom';
import CartClose from '../../assets/wishlist/wishlist-close.svg';
import outline_heart from './../../assets/products-card/outline_heart.png'
import black_filled_heart from './../../assets/products-card/black_filled_heart.png'
import {AddressCard} from '../../components/';


function loadScript(src) {
	return new Promise((resolve) => {
		const script = document.createElement('script')
		script.src = src
		script.onload = () => {
			resolve(true)
		}
		script.onerror = () => {
			resolve(false)
		}
		document.body.appendChild(script)
	})
}

const Cart = () => {
  const [cartTab, setCartTab] = useState('cart');
  const [btnText, setbtnText] = useState('SELECT ADDRESS');
  let {user, authTokens, removeFromCart, base_url} = useContext(AuthContext)
  const [loginModal, setLoginModal] = useState(false);
  const [logoutModal, setLogoutModal] = useState(false);
  const [cartList, setcartList] = useState([])
  const [cartPrice, setcartPrice] = useState([])
  const [addressFormDisplay, setaddressFormDisplay] = useState(false);
  const [addressList, setaddressList] = useState([])
  const [selectedAddress,setSelectedAddress] = useState({id:null})
  let [isLoading, setisLoading] =  useState(true)
  let [orderPlaced, setOrderPlaced] = useState(false)

  const getCartItems = async ()=> {
    if (user) {
      await axios.get(base_url + "/api/cart/get_cart_details/",{
        'headers':{
          'Authorization': 'Bearer ' + String(authTokens.access)
        }
      }).then(function (response) {
        let list = response.data.cart_items.map((ins, i) => <WishlistItemCard key={i} id={ins.id} product={ins.product} displayCartButton={false} closeHandler={removeFromCart} /> )
        setcartList(list)
        setcartPrice(response.data.cart_price)
        setisLoading(false)
        }).catch(function (error) {
          alert(error.response.data['non_field_errors'][0]);
      });
    } else {
      setisLoading(false)
    }
  }

  const getAllAdress = async ()=> {
    if (user && !selectedAddress.id) {
      await axios.get(base_url + "/api/address/",{
        'headers':{
          'Authorization': 'Bearer ' + String(authTokens.access)
        }
      }).then(function (response) {
        setaddressList(response.data)
        }).catch(function (error) {
          alert(error.response.data['non_field_errors'][0]);
      });
    }
  }

  const startRazorpay = async () => {

    const res = await loadScript('https://checkout.razorpay.com/v1/checkout.js')
    if (!res) {
			console.log('Failure loading the Razorpay SDK. PLease make sure you are connected to the internet')
			return
		}

     const razorpayOrderData = await axios.post(base_url + '/api/order/create_razorpay_order/',{amount:cartPrice.total},{
       'headers':{
         'Authorization': 'Bearer ' + String(authTokens.access)
       }
     })

     console.log(razorpayOrderData);

     let { amount, currency, order_id, order_receipt } = razorpayOrderData.data

     const options = {
            key: "rzp_test_lYOMizShZ9dK1d", // Enter the Key ID generated from the Dashboard
            amount: amount.toString(),
            currency: currency,
            name: "Tawisa",
            description: "Test Transaction",
            image: "logo",
            order_id: order_id,
            handler: async function (response) {
                const razorpay_paymentId = response.razorpay_payment_id
                const razorpay_orderId = response.razorpay_order_id
                const razorpay_signature = response.razorpay_signature

                const res = await axios.post(base_url + '/api/order/verify_signature/', {
                  razorpay_paymentId,
                  razorpay_orderId,
                  razorpay_signature
                },{
                  'headers':{
                    'Authorization': 'Bearer ' + String(authTokens.access)
                  }
                })

                document.getElementById('payment_loader').style.display="flex"

                if (res.data.status) {
                  console.log("Payment Successful");
                  let orderData = axios.post(base_url + "/api/order/create_order/",{
                    selectedAddress:selectedAddress,
                    cartPrice:cartPrice,
                    order_receipt:order_receipt,
                    order_id:order_id,
                    razorpay_paymentId:razorpay_paymentId,
                    razorpay_orderId:razorpay_orderId,
                    razorpay_signature:razorpay_signature
                  },{
                    'headers':{
                      'Authorization': 'Bearer ' + String(authTokens.access)
                    }
                  })
                  
                  setOrderPlaced(true)

                } else {
                  console.log("Payment Failed");
                }

                document.getElementById('payment_loader').style.display="none"

            },
            theme: {
                color: "#A88F98",
            },
        };
		const paymentObject = new window.Razorpay(options)
		paymentObject.open()
  }

  useEffect(() => {
    getCartItems()
  }, []);

  useEffect(() => {
    getAllAdress()
  }, [selectedAddress]);

  if (isLoading) {
    return (<HomePageLoader />)
  }

  return (
    <main className='cart'>

    {
      cartList.length == 0 &&
      <div className='wishlist' style={{"padding-top":"0px"}}>
        <h2>Your Cart</h2>
        <div className='wishlist-item-container wishlist-no-auth'>
          <h3>Your Cart is empty</h3>
          <div>
          <Link to='/products'><button>Browse</button></Link>
          </div>
        </div>
      </div>
    }

      { (user && cartList.length != 0) && <section className='cart-tab' >
        <p
          onClick={() => {
            setCartTab('cart')
            setbtnText('SELECT ADDRESS')
          }}
          className={cartTab === 'cart' ? 'cart-tab-active' : 'cart-tabs'}
        >
          Your Cart
        </p>
        <p
          onClick={() => {
            if (cartTab == 'payment') {
              setCartTab('address')
              setbtnText('PROCEED TO CHECKOUT')
            }
          }}
          className={cartTab === 'address' ? 'cart-tab-active' : 'cart-tabs'}
        >
          Your Address
        </p>
        <p
          className={cartTab === 'payment' ? 'cart-tab-active' : 'cart-tabs'}
        >
          Your Payment
        </p>
      </section>}

      {user && <section className='cart-content'>
        {cartTab === 'cart' && (
          <div className='cart-content-left'>
            {cartList}
          </div>
        )}
        {cartTab === 'address' && (
          <div className='cart-content-left'>
            <p className='cart-content-left-head'>Saved Address</p>
            {addressList.map((ins, i) => <AddressCard key={i} address={ins} icon={selectedAddress.id == ins.id? black_filled_heart:outline_heart } iconAction={setSelectedAddress} /> )}

            <p style={{"cursor":"pointer"}} className="add_new_btn" onClick={() => {
              if (addressFormDisplay) {
                setaddressFormDisplay(false)
              } else {
                setaddressFormDisplay(true)
              }
            } }>Add new +</p>

            <AddressForm setaddressList={setaddressList} display={addressFormDisplay} setaddressFormDisplay={setaddressFormDisplay}  />

          </div>
        )}
        {cartTab === 'payment' && (
          <div className='cart-content-left'>
          <p className='cart-content-left-head'>Your Address</p>
            <div className='address-card'>
              <p>
                {selectedAddress?.first_name} {selectedAddress?.last_name} <br />
                {selectedAddress?.phone_number} <br />
                {selectedAddress?.address_line1}, {selectedAddress?.city}, {selectedAddress?.state} - {selectedAddress?.zipcode}
              </p>
            </div>
            <p className='cart-content-left-head'>Products</p>
            <div className='final-products'>
              {cartList}
            </div>
          </div>
        )}

        { (cartList.length != 0) && <div className='cart-content-right'>
          <h3>Price Details ({cartList.length} items)</h3>
          <div className='cart-price-details'>
            <p>Sub Total</p>
            <p>₹ {cartPrice.subtotal}</p>
          </div>
          <div className='cart-price-details'>
            <p>Tax</p>
            <p>₹ {cartPrice.tax}</p>
          </div>
          <div className='cart-price-details'>
            <p>Convinience Charge</p>
            <p>₹ {cartPrice.cvn_charges}</p>
          </div>
          <div className='cart-price-total'>
            <p>Total</p>
            <p>₹ {cartPrice.total}</p>
          </div>
          {(cartTab == 'cart') && <button onClick={() => {
              setCartTab('address')
          }}>SELECT ADDRESS</button> }

          {(cartTab == 'address') && <button onClick={() => {
            if (!selectedAddress.id) {
              alert("Select an address")
              return ;
            }
            setCartTab('payment')
          }}>PROCEED TO CHECKOUT</button> }

          {(cartTab == 'payment') && <button onClick={() => {
            console.log("Place Order");
            startRazorpay()
          }}>PLACE ORDER</button> }

        </div> }
      </section>}

      {cartTab === 'cart' && <RecSection>
        <ItemCard />
        <ItemCard />
        <ItemCard />
        <ItemCard />
        <ItemCard />
        <ItemCard />
      </RecSection>}

      { !user && (
        <div className='wishlist'>
          <h2>Your Cart</h2>
          <div className='wishlist-item-container wishlist-no-auth'>
            <h3>Please log in to save items in your cart</h3>
            <div>
            <button onClick={() => setLogoutModal(true)}>Login</button>
            <button onClick={() => setLoginModal(true)} className="signup">Sign up</button>
            </div>
            <p><span style={{color:"rgba(239, 36, 36, 1)"}}>Having Issues?</span> <span style={{color:"rgba(47, 171, 247, 1)"}}>Contact Us.</span></p>
          </div>
        </div>
      )}

      {loginModal && <LoginModal loginModalhandler={setLoginModal} logoutModalHandler={setLogoutModal} />}
      {logoutModal && <LogoutModal logoutModalHandler={setLogoutModal} loginModalhandler={setLoginModal} />}

      <PaymentLoader />
      { orderPlaced && <ThankYouModal />}
    </main>
  );
};

export default Cart;
