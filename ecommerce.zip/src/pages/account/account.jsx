import React, { useState, useEffect, useRef } from 'react';
import './account.css';
import { WishlistItemCard, AddressForm } from '../../components';
import {useContext} from 'react';
import AuthContext from './../../context/authcontext';
import axios from 'axios'
import {AddressCard} from '../../components/';
import CartClose from '../../assets/wishlist/wishlist-close.svg';
import Cardimg from './../../assets/products-card/card.png'
import editicon from '../../assets/editicon.png';
import jwt_decode from "jwt-decode";
import { AccountDetailsPageLoader} from '../../components/loaders/loaders';

import {Outlet,useNavigate,Link} from 'react-router-dom';


const PersonalDetails = () => {

  let [userDetails, setUserDetails] = useState({})
  let {user, authTokens, base_url } = useContext(AuthContext)
  let [editPersonalDetails, seteditPersonalDetails] = useState(false)
  let [editContactDetails, seteditContactDetails] = useState(false)
  let [isLoading, setisLoading] =  useState(true)

  let profileRef = useRef(null)
  let nameRef = useRef(null)
  let date_of_birthRef = useRef(null)
  let mobileRef = useRef(null)
  let emailRef = useRef(null)
  let addressRef = useRef(null)

  const getUserDetails= async () => {
    console.log(jwt_decode(authTokens.access));
    await axios.get(base_url + "/api/registeruser/" + jwt_decode(authTokens.access).user_id +"/",{
      'headers':{
        'Authorization': 'Bearer ' + String(authTokens.access)
      }
    }).then(function (response) {
      setUserDetails(response.data)
      setisLoading(false)
      }).catch(function (error) {
        console.log(error);
    });
  }

  const SaveChangesToUser = async (e) => {
    e.preventDefault()
    setisLoading(true)
    let body = {
      email:emailRef.current.value,
      first_name:nameRef.current.value,
      date_of_birth:date_of_birthRef.current.value,
      address:addressRef.current.value,
      phone_number:mobileRef.current.value,
    }
    if (profileRef.current.files[0]) {
      body = {...body,profile_pic:profileRef.current.files[0]}
    }
    console.log(body);
    await axios.put(base_url + "/api/registeruser/" + String(jwt_decode(authTokens.access).user_id) + "/",body,{
      'headers':{
        'Authorization': 'Bearer ' + String(authTokens.access),
        'Content-Type': 'multipart/form-data'
      }
    }).then(function (response) {
        setUserDetails(response.data)
        setisLoading(false)
      }).catch(function (error) {
        console.log(error);
    });
    seteditContactDetails(false)
    seteditPersonalDetails(false)
  }


  useEffect(()=> {
    getUserDetails()
  },[])

  if (isLoading) {
    return <AccountDetailsPageLoader />
  }


  return (
    <React.Fragment>
      <h3>Personal Information </h3>
      <p>
        This is your account personal information. You can review your
        information and update your details.
      </p>
      <hr />
      <form onSubmit={SaveChangesToUser}>
      <h4>Personal Details <span><img style={{"margin-left":"24px","cursor":"pointer"}} src={editicon} onClick={() => {
        if (editPersonalDetails) {
          seteditPersonalDetails(false)
        } else {
          seteditPersonalDetails(true)
        }

      }} /></span></h4>
      <div className='account-profile-image'>
        <label htmlFor="profile_pic_input" className='profile-image'>
          <img src={userDetails.profile_pic} />
          <input id="profile_pic_input" type="file" ref={profileRef} disabled={!editPersonalDetails}/>
          { editPersonalDetails && (<div><img src={editicon} /></div>) }
        </label>

        <p style={{"font-weight":"600"}}>Profile Image</p>
      </div>
      <div className='personal-details'>
        <p style={{"font-weight":"600"}}>Name <span>:</span></p>
        <p><input ref={nameRef} type="text" defaultValue={userDetails.first_name} className={editPersonalDetails? "edit_personal_details":""} readOnly={!editPersonalDetails} required /></p>
      </div>
      <div className='personal-details'>
        <p style={{"font-weight":"600"}}>Date of Birth <span>:</span></p>
        <p><input ref={date_of_birthRef} type="text" defaultValue={userDetails.date_of_birth} className={editPersonalDetails? "edit_personal_details":""} readOnly={!editPersonalDetails} required /></p>
      </div>
      <br />
      <h4>Contact Details <span><img style={{"margin-left":"24px","cursor":"pointer"}} src={editicon} onClick={() => {
        if (editContactDetails) {
          seteditContactDetails(false)
        } else {
          seteditContactDetails(true)
        }

      }} /></span></h4>
      <div className='personal-details'>
        <p style={{"font-weight":"600"}}>Mobile <span>:</span></p>
        <p><input ref={mobileRef} type="text" defaultValue={userDetails.phone_number} className={editContactDetails? "edit_personal_details":""} readOnly={!editContactDetails} required /></p>
      </div>
      <div className='personal-details'>
        <p style={{"font-weight":"600"}}>Email <span>:</span></p>
        <p><input ref={emailRef} type="email" defaultValue={userDetails.email} className={editContactDetails? "edit_personal_details":""} readOnly={!editContactDetails} required /></p>
      </div>
      <div className='personal-details'>
        <p style={{"font-weight":"600"}}>Address <span>:</span></p>
        <p><input ref={addressRef} type="text" defaultValue={userDetails.address} className={editContactDetails? "edit_personal_details":""} readOnly={!editContactDetails} required /></p>
      </div>
      <div className='personal-details'>
        { (editContactDetails || editPersonalDetails ) && <button type="submit" >Save</button>}
      </div>
      </form>
    </React.Fragment>
  );
};

const AddressDetails = () => {
  let [addressFormDisplay, setaddressFormDisplay] = useState(false);
  const [addressList, setaddressList] = useState([])
  let {user, authTokens, base_url } = useContext(AuthContext)
  let [isLoading, setisLoading] =  useState(true)

  const removeAddress = async (ins) => {
    await axios.delete(base_url + "/api/address/" + String(ins.id) + "/",{
      'headers':{
        'Authorization': 'Bearer ' + String(authTokens.access)
      }
    }).then(function (response) {
      setaddressList((prev)=> {
        let index = prev.indexOf(ins)
        console.log(index);
        if (index > -1) {
          prev.splice(index,1)
        }
        return [...prev]
      })
      }).catch(function (error) {
        console.log(error);
    });
  }

  const getAllAdress = async ()=> {
    if (user) {
      await axios.get(base_url + "/api/address/",{
        'headers':{
          'Authorization': 'Bearer ' + String(authTokens.access)
        }
      }).then(function (response) {
        console.log(response.data);
        setaddressList(response.data)
        setisLoading(false)
        }).catch(function (error) {
          console.log(error);
      });
    } else {
      setisLoading(false)
    }
  }

  useEffect(() => {
    getAllAdress()
  }, []);

  if (isLoading) {
    return <AccountDetailsPageLoader />
  }

  return (
    <React.Fragment>
      <h3>Your Adresses</h3>
      <p>
        This is your address information. You can review your information and
        update your details.
      </p>
      <br/>
      {addressList.map((ins, i) => <AddressCard icon={CartClose} iconAction={() => removeAddress(ins)} address={ins} /> )}
      <p style={{"cursor":"pointer"}} className="add_new_btn" onClick={() => {
        if (addressFormDisplay) {
          setaddressFormDisplay(false)
        } else {
          setaddressFormDisplay(true)
        }
      } }>Add new +</p>
      <AddressForm setaddressList={setaddressList} display={addressFormDisplay} setaddressFormDisplay={setaddressFormDisplay}/>

    </React.Fragment>
  );
};

const OrderHistoryProductCard = ({title,category_name,selling_price,status}) => {
  return (
    <div className='order-history-product-card'>
      <div className='order-history-product-card-image'><img src={Cardimg} /></div>
      <div className='order-history-product-card-details'>
        <span><span className="dot"></span>Active</span>
        <h3>{title}</h3>
        <button>Track your Package</button>
      </div>
    </div>
  )
}

const OrderHistoryCard = ({id,date,total}) => {
  return (
    <div className='order-history-card'>
      <div className="order-history-card-header">
        <div className="">
          <span className="order-history-card-header-title">Order Date</span>
          <span className="order-history-card-header-value">{date}</span>
        </div>
        <div className="">
          <span className="order-history-card-header-title">Total</span>
          <span className="order-history-card-header-value">Rs. {total}</span>
        </div>
        <div className="order-history-additional-info">
          <span className="order-history-card-header-title">Order ID - {id}</span>
          <span className="order-history-card-header-value"><Link to="1" className="order_link">View details</Link></span>
        </div>
      </div>
      <div className='order-history-card-details'>
        <OrderHistoryProductCard title="Diamond Necklace" category_name="Necklace" selling_price="15748" status="Active" />
        <OrderHistoryProductCard title="Diamond Necklace" category_name="Necklace" selling_price="15748" status="Active" />
      </div>


    </div>
  )
}

const OrderHistory = () => {
  let [isLoading, setisLoading] =  useState(true)
  return (
    <React.Fragment>
      <h3>Your Orders</h3>
      <p>
        This is your order information. You can view your order detials.
      </p>
      <hr />
      <h4>Past Orders</h4>
      <div className='account-order-container'>
        <p>No Orders yet.</p>
        <OrderHistoryCard date="22/12/2022" total="153000" id="4567487554"  />
        <OrderHistoryCard date="22/12/2022" total="153000" id="4567487554"  />
        <OrderHistoryCard date="22/12/2022" total="153000" id="4567487554"  />
      </div>
    </React.Fragment>
  );
};

const OrderDetails = () => {
  return (
    <React.Fragment>
      <h3>Order Details</h3>
      <div className="order-details-line1">
        <span>Ordered on : 12/12/2022</span>
        <span>Order ID : 64867489748</span>
        <a href="#">Invoice</a>
      </div>
      <div className="order-details-line2">
        <div className="order-details-line2-col">
          <h5>Shipping Details</h5>
          <p>
          Ravi Kumar Singh <br />
          ABC Road, Indiranagar <br />
          Bengaluru
          </p>
        </div>
        <div className="order-details-line2-col">
          <h5>Order Summary</h5>
          <p>
          Item Subtotal : Rs. 15546 <br/>
          Shipping : Rs. 4545 <br/>
          Tax: Rs. 64 <br/>
          Discount: - Rs. 4646 <br/>
          Total: Rs. 85756 <br/>
          </p>
        </div>
      </div>
      <h5 className="order_details_heading">Order Details</h5>
      <OrderHistoryProductCard title="Diamond Necklace" category_name="Necklace" selling_price="15748" status="Active" />
      <OrderHistoryProductCard title="Diamond Necklace" category_name="Necklace" selling_price="15748" status="Active" />
    </React.Fragment>
  )
}

const TrackOrder = () => {
  return (
    <div className='track-order-container'>
      <h4>Track your order</h4>
      <div className='track-order-id'>
        <p>Order id : #56253df76f</p>
        <p>Product : Celestial Rings</p>
      </div>
    </div>
  );
};

const GiftCards = () => {
  let [isLoading, setisLoading] =  useState(true)
  return (
    <React.Fragment>
      <h3>Gift Cards</h3>
      <p>This is your Gifft cards section. You can review your gifts.</p>
      <hr />
      <h4>You dont have any gifts</h4>
    </React.Fragment>
  );
};

const MyAccount = () => {

  const navigate = useNavigate()
  const [accountTab, setAccountTab] = useState('personel-details');

  const onClickAccountTabs = (x) => {
    setAccountTab(x)
    navigate(x)
  }

  return (
    <div className='account'>
      <h2>My Account</h2>
      <div className='account-dashboard'>
        <div className='account-menu-container'>
          <div className='account-menu'>
            <p className={`${ accountTab == 'personel-details' && 'active-account-menu'}`} onClick={() => onClickAccountTabs('personel-details')}>Personal Information</p>
            <p className={`${ accountTab == 'address' && 'active-account-menu'}`} onClick={() => onClickAccountTabs('address')}>Your Address</p>
            <p className={`${ accountTab == 'order-history' && 'active-account-menu'}`} onClick={() => onClickAccountTabs('order-history')}>Order History</p>
            <p className={`${ accountTab == 'gift-card' && 'active-account-menu'}`} onClick={() => onClickAccountTabs('gift-card')}>Gift Cards</p>
          </div>
        </div>
        <div className='account-details' style={{"position":"relative"}}>
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export { MyAccount, PersonalDetails, AddressDetails, OrderHistory, TrackOrder, GiftCards, OrderDetails }
