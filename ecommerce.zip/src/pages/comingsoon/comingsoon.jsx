import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';

const ComingSoon = (props) => {
  return (
    <main className='cart'>
      <div className='wishlist' style={{"padding-top":"0px"}}>
        <h2>{props.title}</h2>
          <div className='wishlist-item-container wishlist-no-auth'>
            <h3>Coming Soon!!</h3>
          <div>
            <Link to='/products'><button>Browse</button></Link>
          </div>
        </div>
      </div>
      <br/>
      <br/>
      <br/>
    </main>
  );
};

export default ComingSoon;
