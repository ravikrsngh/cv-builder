import React, { useState, useEffect, useContext } from 'react';
import './product.css';
import { ItemCard } from '../../components';
import ReviewModal from '../../components/review-modal/review-modal';
import Cardimg from './../../assets/products-card/card.png'
import yellowstar from './../../assets/products-card/Star .png'
import bigcard from './../../assets/products-card/bigcard.png'
import smc1 from './../../assets/products-card/smc1.png'
import smc2 from './../../assets/products-card/smc2.png'
import smc3 from './../../assets/products-card/smc3.png'
import smc4 from './../../assets/products-card/smc4.png'
import outline_heart from './../../assets/products-card/outline_heart.png'
import colored_heart from './../../assets/products-card/colored_heart.png'
import greystar from './../../assets/gray_star.png'
import {Link,useLocation,useParams, useNavigate} from 'react-router-dom';
import axios from 'axios';
import parse from "html-react-parser";
import testimonials_profileimg from './../../assets/homepage/testimonial_profile.png';
import AuthContext from './../../context/authcontext';
import { ProductDetailsPageLoader } from '../../components/loaders/loaders';

const Product = () => {
  let {user, authTokens, addToCart, addToWishlist, base_url} = useContext(AuthContext)
  const [selectedTab, setSelectedTab] = useState('description');
  const [isReview, setIsReview] = useState(false);
  const [productDetails,setproductDetails] = useState({})
  const [bigimg, setbigimg]=useState(bigcard)
  const [isWishlisted, setIsWishlisted] = useState(false)
  let [isLoading, setisLoading] =  useState(true)

  let { product } = useParams();
  let navigate = useNavigate();


  const handlereviewClose = (e) => {
    e.stopPropagation();
    setIsReview(false);
  };

  const handleOpenReview = (e) => {
    e.stopPropagation();
    setIsReview(true);
  };

  var stringToHTML = function (str) {
	   var parser = new DOMParser();
	   var doc = parser.parseFromString(str, 'text/html');
	    return doc.body;
  };

  const getProductDetails = async (id) => {


    await axios.get(base_url + "/api/products/" + id + "/get_product_details/").then(function (response) {
        response = response.data
        console.log(response);
        response.short_description = parse(response.short_description)
        response.long_description = parse(response.long_description)
        response.shipping_details = parse(response.shipping_details)
        response.return_details = parse(response.return_details)
        setproductDetails(response)
        setisLoading(false)
      }).catch(function (error) {
          console.log(error);
      });

      /* Check Wishlist */
      let wishlist_id = []
      if (user) {
        if (localStorage.getItem("wishlistChanged") == "true") {
          await axios.get(base_url + "/api/wishlist/",{
            'headers':{
              'Authorization': 'Bearer ' + String(authTokens.access)
            }
          }).then(function (response) {
              response.data.map((ins) => wishlist_id.push(ins.product.id))
              localStorage.setItem("wishlist",JSON.stringify(wishlist_id))
              localStorage.setItem("wishlistChanged","false")
            }).catch(function (error) {
                console.log(error);
            });
        }
        else {
          if (localStorage.getItem("wishlist")) {
            wishlist_id = JSON.parse(localStorage.getItem("wishlist"))
          }
        }
        if (wishlist_id.includes(parseInt(product))) {
          if (!isWishlisted) {
            setIsWishlisted(true)
          }
        } else {
          if (isWishlisted) {
            setIsWishlisted(false)
          }
        }
      }
  }

  const SubmitReview = async (name,review) => {
    let body = {
      "product":product,
      "name":name,
      "review": review
    }
    await axios.post('/api/review/',body,{
      'headers':{
        'Authorization': 'Bearer ' + String(authTokens.access)
      }
    }).then((response) => {
      console.log(response);
      alert("Submitted Successfully.")
      location.reload()
    }).catch((err) => {
      console.log(err);
    })
  }

  useEffect(() => {
    getProductDetails(product)
  }, []);

  if (isLoading) {
    return <ProductDetailsPageLoader />
  }

  return (
    <section className='product-page' onClick={handlereviewClose}>
      <div className='product-details'>
        <div className='product-details-left'>
          <div className='product-details-small-images'>
            <div className='small-image-preview' onClick={() => setbigimg(smc1)}><img src={smc1} /></div>
            <div className='small-image-preview' onClick={() => setbigimg(smc2)}><img src={smc2} /></div>
            <div className='small-image-preview' onClick={() => setbigimg(smc3)}><img src={smc3} /></div>
            <div className='small-image-preview' onClick={() => setbigimg(smc4)}><img src={smc4} /></div>
          </div>
          <div className='product-details-images'><img src={bigimg}/></div>
        </div>
        <div className='product-details-right'>
          <p className='product-nav-info'>
            Home {`>`} Shop {`>`} {productDetails?.category?.name} {`>`} {productDetails.title}
          </p>
          <div className='product-detail-reviews'>
          {productDetails.avg_rating >= 1? (<img src={yellowstar} />) : <img src={greystar} /> }
          {productDetails.avg_rating >= 2? (<img src={yellowstar} />) : <img src={greystar} /> }
          {productDetails.avg_rating >= 3? (<img src={yellowstar} />) : <img src={greystar} /> }
          {productDetails.avg_rating >= 4? (<img src={yellowstar} />) : <img src={greystar} /> }
          {productDetails.avg_rating >= 5? (<img src={yellowstar} />) : <img src={greystar} /> }
            <p>| {productDetails.total_reviews} Reviews</p>
          </div>
          <h2 className='product-name'>{productDetails.title}</h2>
          <p className='product-price'>₹{productDetails.selling_price}</p>
          <hr />
          {productDetails.short_description}
          <br />
          <div className='product-cta'>
            <button className='product-add-to-cart' onClick={(e)=>{
              if (user) {
                addToCart(product)
              } else {
                handleOpenReview(e)
              }
            }}>Add To Cart</button>
            <div className='product-wishlist'>
              <img src={isWishlisted? colored_heart:outline_heart } onClick={(e)=>{
                if (user) {
                  addToWishlist(product)
                  setIsWishlisted(true)
                } else {
                  handleOpenReview(e)
                }
              }} />
            </div>
          </div>
          <button className='product-buy'onClick={(e)=>{
            if (user) {
              addToCart(product)
              navigate('/cart')
            } else {
              handleOpenReview(e)
            }
          }}>Buy It Now</button>
        </div>
      </div>
      <hr />
      <div className='product-tabs-container'>
        <div className='product-tabs'>
          <p
            className={selectedTab === 'description' && 'active-tab'}
            onClick={() => setSelectedTab('description')}
          >
            Description
          </p>
          <p
            className={selectedTab === 'shipping' && 'active-tab'}
            onClick={() => setSelectedTab('shipping')}
          >
            Shipping
          </p>
          <p
            className={selectedTab === 'returns' && 'active-tab'}
            onClick={() => setSelectedTab('returns')}
          >
            Returns
          </p>
        </div>
        <div className='product-tabs-content'>
          {selectedTab === 'description' && (
            <div>
              <span>Product Information</span> <br/>
              <div className="product-tabs-content-table">
                <p>Stock Number:</p>
                <p>{productDetails.stock_number}</p>
                <p>Metal / Purity:</p>
                <p>Gold {productDetails.gold_purity.name} Diamond {productDetails.diamond_purity.name}</p>
                <p>Gross Weight:</p>
                <p>{productDetails.gross_weight} g</p>
                <p>Net Weight:</p>
                <p>{productDetails.net_weight} g</p>
                <p>Height:</p>
                <p>{productDetails.height}</p>
                <p>Width:</p>
                <p>{productDetails.width}</p>
              </div>

              <span>Gold Component Details</span>
              <div className="product-tabs-content-table">
                <p>Metal Purity</p>
                <p>{productDetails.gold_purity.name}</p>
                <p>Weight</p>
                <p>{productDetails.gold_weight} g</p>
              </div>

              <span>Diamond Component Details</span>
              <div className="product-tabs-content-table">
                <p>Metal Purity</p>
                <p>{productDetails.diamond_purity.name}</p>
                <p>Weight</p>
                <p>{productDetails.diamond_weight} ct</p>
              </div>

              <span>Price Breakup</span>
              <div className="product-tabs-content-table-4">
                <p><span>Component</span></p>
                <p><span>Rate</span></p>
                <p><span>Weight</span></p>
                <p><span>Value</span></p>

                <p>Gold ({productDetails.gold_purity.name})</p>
                <p>Rs. {productDetails.gold_purity.price} /g</p>
                <p>{productDetails.gold_weight} g</p>
                <p>Rs. {productDetails.material_prices.gold_price}</p>

                <p>Diamond ({productDetails.diamond_purity.name})</p>
                <p>Rs. {productDetails.diamond_purity.price} /g</p>
                <p>{productDetails.diamond_weight} g</p>
                <p>Rs. {productDetails.material_prices.diamond_price}</p>

                <p>Making Charges</p>
                <p>-</p>
                <p>-</p>
                <p>Rs. {productDetails.making_charges}</p>

                <p>Total</p>
                <p>-</p>
                <p>-</p>
                <p>Rs. {productDetails.mrp}</p>

              </div>

            </div>
          )}
          {selectedTab === 'shipping' && productDetails.shipping_details}
          {selectedTab === 'returns' && productDetails.return_details}
        </div>
      </div>
      <hr />
      <div className='product-customer-reviews'>
        <h2>Reviews by our customers</h2>
        <div className='review-containers'>
        {productDetails.reviews?.map((ins) => {
            return (
              <div className='reviews'>
                <div className='user-profile-picture'><img src={testimonials_profileimg} /></div>
                <div className='user-details'>
                  <p className="user-details-name">{ins.name}</p>
                  <p className="user-details-review">
                    {ins.review}
                  </p>
                </div>
              </div>
            )
          })}

        </div>
        <div>
          <button onClick={handleOpenReview}>
            Leave a Rating For The Product
          </button>
        </div>
      </div>
      {isReview && <ReviewModal submitReview = {SubmitReview} />}
      <div className='prod-rec-section'>
        <h2>You may also like</h2>
        <div className='prod-rec-items'>
          {productDetails.related_products?.map((ins, i) => {
            return (
              <ItemCard key={i} id={ins.id} title={ins.title} stars={ins.avg_rating} price={ins.selling_price} images={ins.product_images} />
            )
          })}

        </div>
      </div>
    </section>
  );
}

export default Product;
