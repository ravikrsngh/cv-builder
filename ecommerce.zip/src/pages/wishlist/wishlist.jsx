import React from 'react';
import { WishlistItemCard, ItemCard, RecSection } from '../../components';
import './wishlist.css';
import {useContext, useState, useEffect} from 'react';
import AuthContext from './../../context/authcontext';
import LoginModal from '../../components/login-modal/login';
import LogoutModal from '../../components/logout-modal/logout';
import { HomePageLoader} from '../../components/loaders/loaders';
import axios from 'axios';
import {Link} from 'react-router-dom'

const Wishlist = () => {

  let {user,authTokens, removeFromWishlist,base_url} = useContext(AuthContext)
  const [loginModal, setLoginModal] = useState(false);
  const [logoutModal, setLogoutModal] = useState(false);
  const [wishlistList, setwishlistList] = useState([])
  let [isLoading, setisLoading] =  useState(true)

  const getWishlistItems = async ()=> {
    if (user) {
      await axios.get(base_url + "/api/wishlist/",{
        'headers':{
          'Authorization': 'Bearer ' + String(authTokens.access)
        }
      }).then(function (response) {
        console.log(response.data);
        let list = response.data.map((ins, i) => <WishlistItemCard key={i} id={ins.id} product={ins.product} displayCartButton={true} closeHandler={removeFromWishlist} /> )
        setwishlistList(list)
        setisLoading(false)
        }).catch(function (error) {
          alert(error.response.data['non_field_errors'][0]);
        });
    } else {
      setisLoading(false)
    }
  }


  useEffect(() => {
    getWishlistItems()
  }, []);

  if (isLoading) {
    return (<HomePageLoader />)
  }

  return (
    <section>
        <div className='wishlist'>
          <h2>Your Wishlist</h2>
          {user? (
            <div className='wishlist-item-container'>
              {wishlistList}
            </div>
          ):(
            <div className='wishlist-item-container wishlist-no-auth'>
              <h3>Please log in to save items in wishlist</h3>
              <div>
              <button onClick={() => setLogoutModal(true)}>Login</button>
              <button onClick={() => setLoginModal(true)} className="signup">Sign up</button>
              </div>
              <p><span style={{color:"rgba(239, 36, 36, 1)"}}>Having Issues?</span> <span style={{color:"rgba(47, 171, 247, 1)"}}>Contact Us.</span></p>
            </div>
          )}
          {
            (user && wishlistList.length == 0) &&
            <div className='wishlist' style={{"padding-top":"0px"}}>
              <div className='wishlist-item-container wishlist-no-auth'>
                <h3>Your wishlist is empty</h3>
                <div>
                <Link to='/products'><button>Browse</button></Link>
                </div>
              </div>
            </div>
          }

        </div>


      {user && <RecSection>
        <ItemCard />
        <ItemCard />
        <ItemCard />
        <ItemCard />
        <ItemCard />
        <ItemCard />
      </RecSection>}

      {loginModal && <LoginModal loginModalhandler={setLoginModal} logoutModalHandler={setLogoutModal} />}
      {logoutModal && <LogoutModal logoutModalHandler={setLogoutModal} loginModalhandler={setLoginModal} />}

    </section>
  )
};

export default Wishlist;
