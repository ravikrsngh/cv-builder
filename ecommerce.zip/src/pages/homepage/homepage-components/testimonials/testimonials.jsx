import React, { useEffect, useState } from 'react';
import './testimonials.css';
import testimonials_profileimg from './../../../../assets/homepage/testimonial_profile.png';




const TestimonialsCard = (props) => {
  return (
    <div className="testimonials_card">
      <div className="testimonials_profile">
        <img src={props.img} />
      </div>
      <div className="testimonials_info">
        <span className="inverted_comma">“</span>
        <p>{props.testimonial}</p>
        <span className="testimonials_name">{props.name}</span>
      </div>
    </div>
  )
}

const Testimonials = () => {

  let [slidehsowstatus, setslideshowstatus]= useState(0)
  let [slidehsowstyle, setslideshowstyle]= useState(0)

  const slideShow = () => {
    let x = slidehsowstatus + 1;
    if (x > 2) {
      x = 0
    }
    setslideshowstatus(x)
    let tranformPosition = -1 * 100 * x
    setslideshowstyle(tranformPosition)
  }

  const moveToSlide = (x) => {
    console.log(x);
    setslideshowstyle(x)
    setslideshowstatus(x/-100)
  }

  useEffect(() => {
    let interval =  setInterval(()=> {
            slideShow()
        }, 4000)
        return ()=> clearInterval(interval)

  }, [slidehsowstatus]);

  return (
    <section className='testimonials'>
      <h2>Testimonials</h2>
      <div className="testimonials_container">
        <div className="testimonials_page_container" style={{transform: `translateX(${slidehsowstyle}%)`}}>
          <div className="testimonials_page">
            <TestimonialsCard img={testimonials_profileimg} testimonial="The item purchased was as per the image they had. Dimensions were also perfect. Looks very authentic. After sales support is extremely good too." name="SOFIA BRICHET"/>
            <TestimonialsCard img={testimonials_profileimg} testimonial="The item purchased was as per the image they had. Dimensions were also perfect. Looks very authentic. After sales support is extremely good too." name="SOFIA BRICHET"/>
          </div>
          <div className="testimonials_page">
            <TestimonialsCard img={testimonials_profileimg} testimonial="The was as per the image they had. erfect. Looks very authentic. After sales support is extremely good too." name="SOFIA BRICHET"/>
            <TestimonialsCard img={testimonials_profileimg} testimonial="The item purchased was as per the image they had. Dimensions were also perfect. Looks very authentic. After sales support is extremely good too." name="SOFIA BRICHET"/>
          </div>
          <div className="testimonials_page">
            <TestimonialsCard img={testimonials_profileimg} testimonial="The item purchased was as per the image they had. Dimensions were also perfect. Looks very authentic. After sales support is extremely good too." name="SOFIA BRICHET"/>
            <TestimonialsCard img={testimonials_profileimg} testimonial="The item purchased was as per the image they had. Dimensions were also perfect. Looks very authentic. After sales support is extremely good too." name="SOFIA BRICHET"/>
          </div>
        </div>
      </div>
      <div className="testimonials_navigation">
        <div onClick={()=> moveToSlide(0)} className={`${slidehsowstatus == 0? 'testimonials_active': ''}`}></div>
        <div onClick={()=> moveToSlide(-100)} className={`${slidehsowstatus == 1? 'testimonials_active': ''}`}></div>
        <div onClick={()=> moveToSlide(-200)} className={`${slidehsowstatus == 2? 'testimonials_active': ''}`}></div>
      </div>
    </section>
  );
};

export default Testimonials;
