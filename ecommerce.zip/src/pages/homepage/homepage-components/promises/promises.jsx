import React from 'react';
import './promises.css';
import wrenchicon from './../../../../assets/promises/Wrench.png';
import lotusicon from './../../../../assets/promises/FlowerLotus.png'
import wandicon from './../../../../assets/promises/MagicWand.png'

const Promises = () => {
  return (
    <section className='promises'>
      <div className='promises-img'></div>
      <div className='promises-right'>
        <h2>Tawisa Promises</h2>
        <div className='promises-item'>
          <div className='promises-icon'>
            <img src={wrenchicon} />
          </div>
          <p>Lifetime jewellery maintenance Service</p>
        </div>
        <div className='promises-item'>
          <div className='promises-icon'>
            <img src={lotusicon} />
          </div>
          <p>100% Purity of jewellery</p>
        </div>
        <div className='promises-item'>
          <div className='promises-icon'>
            <img src={wandicon} />
          </div>
          <p>Exequisite jewellery made for each singularity</p>
        </div>
      </div>
    </section>
  );
};

export default Promises;
