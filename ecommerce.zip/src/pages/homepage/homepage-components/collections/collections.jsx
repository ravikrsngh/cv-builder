import axios from 'axios';
import React, { useEffect, useState, useContext } from 'react';
import './collections.css';
import collectioncardimg from './../../../../assets/collection/1.png'
import { Link, useNavigate } from 'react-router-dom'
import AuthContext from './../../../../context/authcontext';
import { HomePageLoader } from '../../../../components/loaders/loaders';



const CollectionCard = (props) => {
  let navigate = useNavigate()
  return (
    <div className='collections-item-container' onClick={() => navigate(`/products/${props.id}`)}>
      <div className='collections-item'>
        <div className='collections-img'><img src={collectioncardimg} /></div>
        <p>{props.title}</p>
        <p className='collections-item-price'>Rs. {props.price}</p>
      </div>
    </div>
  )
}

const Collections = () => {
  const [currentTab, setCurrentTab] = useState('new-arrived');
  let [collectionList, setcollectionList] =  useState([])
  let [isLoading, setisLoading] =  useState(true)

  const { base_url } = useContext(AuthContext)

  const filterCollection = async (search_string) => {
    console.log(base_url + "/api/products" + search_string)
    await axios.get(base_url + "/api/products" + search_string).then(function (response) {
        let list = response.data.map((ins, i) => <CollectionCard key={i} id={ins.id} img="" title={ins.title} price={ins.selling_price} />)
        setcollectionList(list)
        setisLoading(false)
      }).catch(function (error) {
          console.log(error);
      });


  }

  useEffect(() => {
    let search_string = ""
    if (currentTab === 'new-arrived') {
      search_string = "?tags=New Arrivals"
    }
    if (currentTab === 'on-sale') {
      search_string = "?tags=On Sale"
    }
    filterCollection(search_string)
  }, [currentTab]);

  if (isLoading) {
    return <HomePageLoader />
  }
  return (
    <section className='collections'>
      <h2>Collections</h2>
      <div className="collection-tab-header-container">
        <div className='collections-tab-header'>
          <div
            className={
              currentTab === 'new-arrived'
                ? 'collections-tab-active'
                : 'collections-tab'
            }
            onClick={() => setCurrentTab('new-arrived')}
          >
            <p>New Arrived</p>
          </div>
          <div
            className={
              currentTab === 'on-sale'
                ? 'collections-tab-active'
                : 'collections-tab'
            }
            onClick={() => setCurrentTab('on-sale')}
          >
            <p>On Sale</p>
          </div>
        </div>
      </div>
      <div className="all_collection_items">
      {collectionList}
      </div>
    </section>
  );
};

export default Collections;
