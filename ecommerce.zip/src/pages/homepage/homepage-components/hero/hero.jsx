import React, { useEffect, useState } from 'react';
import './hero.css';
import { SubscribeModal } from '../../../../components/';
import LoginModal from '../../../../components/login-modal/login';
import { Link } from 'react-router-dom';
import mobileheroimg from './../../../../assets/homepage/mobilehero.png';
import mobilesection2 from './../../../../assets/homepage/mobilesection2.png';
import festivecard1 from './../../../../assets/homepage/festivecard1.png';
import festivecard2 from './../../../../assets/homepage/festivecard2.png';
import festivecard3 from './../../../../assets/homepage/festivecard3.png';
import festivecard4 from './../../../../assets/homepage/festivecard4.png';
import festivecard5 from './../../../../assets/homepage/festivecard5.png';
import earrings from './../../../../assets/homepage/earrings.png';
import bracelets from './../../../../assets/homepage/bracelets.png';
import rings from './../../../../assets/homepage/rings.png';
import necklace from './../../../../assets/homepage/necklace.png';
import others from './../../../../assets/homepage/others.png';

const Hero = () => {
  let [isSubscribe, setIsSubscribe] = useState(false);
  let [slidehsowstatus, setslideshowstatus]= useState(0)
  let [slidehsowstyle, setslideshowstyle]= useState(0)

  const slideShow = () => {
    let x = slidehsowstatus + 1;
    if (x > 2) {
      x = 0
    }
    setslideshowstatus(x)
    let tranformPosition = -1 * 100 * x
    setslideshowstyle(tranformPosition)
  }

  const moveToSlide = (x) => {
    console.log(x);
    setslideshowstyle(x)
    setslideshowstatus(x/-100)
  }

  useEffect(() => {
    let interval =  setInterval(()=> {
            slideShow()
        }, 4000)
        return ()=> clearInterval(interval)

  }, [slidehsowstatus]);

  return (
    <section>
      {isSubscribe && <SubscribeModal setIsSubscribe={setIsSubscribe} />}
      <div className='homepage-hero-slidehsow'>
        <div className='homepage-hero-slidehsow-container' style={{transform: `translateX(${slidehsowstyle}%)`}}>
          <div  className='homepage-hero-section'>
            <h1>
              Discover a world of
              <br /> Finest Jewellery
            </h1>
            <Link to='/products?'><button>Explore Collections</button></Link>
          </div>
          <div  className='homepage-hero-section'>
            <h1>
              Discover a world of
              <br /> Section2 Jewellery
            </h1>
            <Link to='/products?'><button>Explore Collections</button></Link>
          </div>
          <div  className='homepage-hero-section'>
            <h1>
              Discover a world of
              <br /> Section3 Jewellery
            </h1>
            <Link to='/products?'><button>Explore Collections</button></Link>
          </div>
        </div>
        <div className="homepage-hero-slidehsow-nav">
          <button  onClick={()=> moveToSlide(0)} className={`${slidehsowstatus == 0? 'homepage-hero-slidehsow-active': ''}`}></button>
          <button onClick={()=> moveToSlide(-100)} className={`${slidehsowstatus == 1? 'homepage-hero-slidehsow-active': ''}`}></button>
          <button onClick={()=> moveToSlide(-200)} className={`${slidehsowstatus == 2? 'homepage-hero-slidehsow-active': ''}`}></button>
        </div>
      </div>

      <div className="hero-mobile">
        <div className="mobile-catgories">
          <Link to='/products?category=Earrings'>
            <img src={earrings} />
            <span>Earrings</span>
          </Link>
          <Link to='/products?category=Braclets'>
            <img src={bracelets} />
            <span>Braclets</span>
          </Link>
          <Link to='/products?category=Rings'>
            <img src={rings} />
            <span>Rings</span>
          </Link>
          <Link to='/products?category=Necklaces'>
            <img src={necklace} />
            <span>Necklace</span>
          </Link>
          <Link to='/products?category=Others'>
            <img src={others} />
            <span>Others</span>
          </Link>
        </div>
        <div><Link to='/products'><img src={mobileheroimg} /></Link></div>
      </div>
      <div className="hero-section-2">
        <Link to='/products'><img src={mobilesection2} /></Link>
      </div>
      <div className="mobile-third-section-container">
        <h2>Festive Special</h2>
        <div className="mobile-third-section">
          <Link to='/products?tags=Get Pooja Ready'><img src={festivecard1} /></Link>
          <Link to='/products?tags=Minimal yet Classy'><img src={festivecard2} /></Link>
          <Link to='/products?tags=The Goddess'><img src={festivecard3} /></Link>
          <Link to='/products?tags=Go Gorgeous'><img src={festivecard4} /></Link>
          <Link to='/products?tags=We hear Party!!!'><img src={festivecard5} /></Link>
        </div>
        <div className="mobile-extra-section">
          <Link to='/products'><p>View Complete Collection</p></Link>
        </div>
      </div>

    </section>
  );
};

export default Hero;
