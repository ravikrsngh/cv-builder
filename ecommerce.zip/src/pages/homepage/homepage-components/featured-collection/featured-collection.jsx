import React from 'react';
import './featured-collection.css';
import { Link, useNavigate } from 'react-router-dom'

const FeaturedCollection = () => {
  let navigate = useNavigate()
  return (
    <section className='featured-collection'>
      <h2>Featured Collections</h2>
      <div className='featured-collection-container'>
        <div className='featured-collection-top'>
          <div className='featured-collection-card  featured-collection-item-1' onClick={() => navigate('/products?tags=Adorable Beauty')}>
            Adorable
            <br /> Beauty
          </div>
          <div className='featured-collection-card  featured-collection-item-2' onClick={() => navigate('/products?tags=Mesmerizing Collections')}>
            Mesmerizing
            <br /> Collections
          </div>
        </div>
        <div className='featured-collection-bottom'>
          <div className='featured-collection-card  featured-collection-item-3' onClick={() => navigate('/products?tags=Flawless Collections')}>
            Flawless
            <br /> Collections
          </div>
          <div className='featured-collection-card  featured-collection-item-4' onClick={() => navigate('/products?tags=Personalized Collections')}>
            Personalized <br />
            Collections
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturedCollection;
