import React from 'react';
import './be-spoke-design.css';
import {Link} from 'react-router-dom';

const BeSpokeDesigns = () => {
  return (
    <section className='bespoke-design'>
      <h1>Bespoke Designs</h1>
      <p>
        Consize and minimalistice designer jewelry , which is handcrafted
         to emphasize your singularity
      </p>
      <Link to='/products?'><button>Explore Collections</button></Link>
    </section>
  );
};

export default BeSpokeDesigns;
