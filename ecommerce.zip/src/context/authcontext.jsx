import {createContext, useState, useEffect } from 'react';
import {useNavigate} from 'react-router-dom';
import axios from 'axios';
import jwt_decode from "jwt-decode";

const AuthContext = createContext() //creating the context

export default AuthContext;





export const AuthProvider = ({children}) => {
  let [user, setUser] = useState(() => localStorage.getItem('authTokens')? true : false);
  let [authTokens,setAuthTokens] = useState(() => localStorage.getItem('authTokens')? JSON.parse(localStorage.getItem('authTokens')) : null)

  const base_url = "http://127.0.0.1:8000"
  //const base_url = ""

  let navigate = useNavigate();

  const LoginUserWithEmailPassword = async (e) => {
    e.preventDefault()
    let body ={
      username:e.target.email.value,
      password:e.target.password.value
    }
    await axios.post(base_url + '/api/token/',body).then(function (response) {
        setAuthTokens(response.data)
        localStorage.setItem('authTokens',JSON.stringify(response.data))
        location.reload();
      }).catch(function (error) {
          console.log(error);
      });
  }

  const SignUpUserWithEmailPassword = async (e) => {
    e.preventDefault()
    let body ={
      first_name:e.target.name.value,
      email:e.target.email.value,
      password:e.target.password.value,
      phone_number:"-"
    }
    await axios.post(base_url + "/api/registeruser/",body).then(function (response) {
        axios.post(base_url + '/api/token/',{username:e.target.email.value,password:e.target.password.value}).then(function (response) {
          setAuthTokens(response.data)
          localStorage.setItem('authTokens',JSON.stringify(response.data))
          location.reload();
        }).catch(function (error) {
            console.log(error);
        });
      }).catch(function (error) {
          console.log(error);
      });
  }

  const LogoutUser = () => {
    setUser(false)
    setAuthTokens(null)
    localStorage.removeItem('authTokens')
    navigate('/')
  }

  const addToWishlist = async (id) => {
    await axios.post(base_url + "/api/wishlist/",{product:id},{
      'headers':{
        'Authorization': 'Bearer ' + String(authTokens.access)
      }
    }).then(function (response) {
      console.log(response.data);
      localStorage.setItem('wishlistChanged',"true")
      alert("Item Added to the wishlist")
      }).catch(function (error) {
        alert(error.response.data['non_field_errors'][0]);
      });
  }

  const removeFromWishlist = async (id) => {
    await axios.delete(base_url +"/api/wishlist/" + id +"/",{
      'headers':{
        'Authorization': 'Bearer ' + String(authTokens.access)
      }
    }).then(function (response) {
      console.log(response.data);
      localStorage.setItem("wishlistChanged","true")
      location.reload()
      }).catch(function (error) {
        alert(error.response.data['non_field_errors'][0]);
      });
  }

  const addToCart = async (id) => {
    await axios.post(base_url +"/api/cart/",{product:id,qty:1},{
      'headers':{
        'Authorization': 'Bearer ' + String(authTokens.access)
      }
    }).then(function (response) {
      console.log(response.data);
      localStorage.setItem('cartChanged',"true")
      alert("Item Added to the Cart")
      }).catch(function (error) {
        alert(error.response.data['non_field_errors'][0]);
      });
  }

  const removeFromCart = async (id) => {
    await axios.delete(base_url +"/api/cart/" + id +"/",{
      'headers':{
        'Authorization': 'Bearer ' + String(authTokens.access)
      }
    }).then(function (response) {
      console.log(response.data);
      localStorage.setItem('cartChanged',"true")
      location.reload()
      }).catch(function (error) {
        alert(error.response.data['non_field_errors'][0]);
      });
  }



  let contextData = {
    user: user,
    authTokens:authTokens,
    LoginUserWithEmailPassword:LoginUserWithEmailPassword,
    SignUpUserWithEmailPassword:SignUpUserWithEmailPassword,
    LogoutUser:LogoutUser,
    addToWishlist:addToWishlist,
    removeFromWishlist:removeFromWishlist,
    addToCart:addToCart,
    removeFromCart:removeFromCart,
    base_url:base_url,
  }

  return(
          <AuthContext.Provider value={contextData} >
              {children}
          </AuthContext.Provider>
      )
}
